<?php

//event post type
function universisty_post_types()
{
    register_post_type('event', array(
        'has_archive' => true,
        'rewrite'=>array('slug'=>'events'),
        'public' => true,
        'labels' => array(
            'name'=>'Events',
            'add_new_item'=>'Add New Event',
            'edit_item'=>'Edit Event',
            'all_items' => 'All Events',
            'singular_name' =>'Event'
        ),
        'menu_icon'=>'dashicons-calendar',
        'show_in_rest'=>true,
        'supports'=> array('title','editor','excerpt')
        
    ));

    //program post type

    register_post_type('program', array(
        'has_archive' => true,
        'rewrite'=>array('slug'=>'programs'),
        'public' => true,
        'labels' => array(
            'name'=>'Programs',
            'add_new_item'=>'Add New Program',
            'edit_item'=>'Edit Program',
            'all_items' => 'All Program',
            'singular_name' =>'Program'
        ),
        'menu_icon'=>'dashicons-awards',
        'show_in_rest'=>true,
        'supports'=> array('title','editor')
        
    ));

    register_post_type('professor', array(
        'public' => true,
        'labels' => array(
            'name'=>'Professors',
            'add_new_item'=>'Add New Professor',
            'edit_item'=>'Edit Professor',
            'all_items' => 'All Professor',
            'singular_name' =>'Professor'
        ),
        'menu_icon'=>'dashicons-welcome-learn-more',
        'show_in_rest'=>true,
        //in addtioan to feature in functions.php need to add thumbnail to enable for custom post types
        'supports'=> array('title','editor','thumbnail')
        
    ));
}




add_action('init', 'universisty_post_types');

?>