<?php


function pageBanner($args=NULL)
{
    //page banner logic will live here

    if (!isset($args['title'])) {
        $args['title'] = get_the_title();
    }
    if (!isset($args['subTitle'])) {
        $args['subTitle'] = get_field('page_banner_subtitle');
    }
    if (!isset($args['photo'])) {
        if (get_field('page_banner_image')) {
            $args['photo'] = get_field('page_banner_image')['sizes']['pageBanner'];
        }
        else{
            $args['photo']=get_theme_file_uri('/images/ocean.jpg');
        }
    }



?>
    <div class="page-banner">
        <div class="page-banner__bg-image" style="background-image: url(<?php echo $args['photo']?>)"></div>
        <div class="page-banner__content container container--narrow">
            <h1 class="page-banner__title"><?php echo $args['title'] ?></h1>
            <div class="page-banner__intro">
                <?php echo $args['subTitle'] ?>
            </div>
        </div>
    </div>

<?php
}




function university_files()
{
    wp_enqueue_script('main-university-javascript', get_theme_file_uri('/build/index.js'), array('jquery'), '1.0', true);
    wp_enqueue_style('font-awsome', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
    wp_enqueue_style('university_main_styles', get_theme_file_uri('/build/style-index.css'));
    wp_enqueue_style('university_extra_styles', get_theme_file_uri('/build/index.css'));
    wp_enqueue_style('cutom-google-fonts', "//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i|Roboto:100,300,400,400i,700,700i");
}


add_action('wp_enqueue_scripts', 'university_files');

function university_features()
{
    //register navigations
    register_nav_menu('headerMenuLocation', 'Header Menu Location');
    register_nav_menu('footerMenuLocation1', 'Footer Location 1');
    register_nav_menu('footerMenuLocation2', 'Footer Location 2');

    add_theme_support('title-tag');
    //enable featured images. 
    add_theme_support('post-thumbnails');

    //for Professor imags
    add_image_size('professorLandscape', 400, 260, true);
    add_image_size('professorPortarite', 480, 650, true);

    //for banner
    add_image_size('pageBanner', 1500, 350, true);
}


add_action('after_setup_theme', 'university_features');

function university_adjust_queries($query)
{

    //for program query
    if (!is_admin()  and is_post_type_archive('program') and is_main_query()) {
        $query->set('orderby', 'title');
        $query->set('order', 'ASC');
        $query->set('post_per_page', -1);
    }
    //for event query
    if (!is_admin() and is_post_type_archive('event') and $query->is_main_query()) {
        $today = date('Ymd');
        $query->set('meta_key', 'event_date');
        $query->set('orderby', 'meta_value_num');
        $query->set('order', 'ASC');
        $query->set(
            'meta_query',
            array(
                'key' => 'event_date',
                'compare' => '>=',
                'value' => $today,
                'type' => 'numeric'
            )
        );
    }
}

add_action('pre_get_posts', 'university_adjust_queries');
