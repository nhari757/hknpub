<?php
get_header();
while (have_posts()) {
    the_post(); 
    
    pageBanner();
    ?>


    <div class="container container--narrow page-section">

        <div class=generic-conent>

            <div class="row group">
                <div class="one-third">
                    <?php the_post_thumbnail(); ?>
                </div>
                <div class="two-thirds">
                    <?php the_content() ?>
                </div>
            </div>
        </div>

        <div>
            <?php
            $relatedProgrms = get_field('related_programs');
            if ($relatedProgrms) {
                echo '<hr class="section-break"/>';
                echo '<h2 class="headline headline--medium">Subject Tought</h2>';
                echo '<ul class="link-list min-list">';
                foreach ($relatedProgrms as $program) {
            ?>
                    <li>
                        <a href="<?php echo get_the_permalink($program) ?>">
                            <? echo get_the_title($program) ?>
                        </a>
                    </li>
            <?php
                }
            }
            echo "</ul>";
            ?>
        </div>
    </div>
<?php
}

get_footer();
?>